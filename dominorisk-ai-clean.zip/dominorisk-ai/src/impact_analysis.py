import json
from pathlib import Path
import networkx as nx

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def find_direct_impact(G: nx.DiGraph, region: str, industries: list) -> list:
    return [n for n, attrs in G.nodes(data=True)
            if attrs.get("country") == region and attrs.get("industry") in industries]


def find_indirect_impact(G: nx.DiGraph, direct_ids: list, max_hops: int = 3) -> dict:
    """Reverse BFS: who depends on the direct-impact nodes, hop by hop.
    Returns {node_id: hop_distance} for every indirectly affected node,
    so the frontend can animate the cascade one hop at a time."""
    visited = {n: 0 for n in direct_ids}
    frontier = set(direct_ids)

    for hop in range(1, max_hops + 1):
        next_frontier = set()
        for n in frontier:
            for dependent in G.predecessors(n):  # dependent -> n (buyer -> supplier)
                if dependent not in visited:
                    visited[dependent] = hop
                    next_frontier.add(dependent)
        if not next_frontier:
            break
        frontier = next_frontier

    return {n: h for n, h in visited.items() if h > 0}


def explain_risk(G: nx.DiGraph, node_id: str, risk_scores: dict) -> dict:
    """Real structural reasons for a node's risk score — no invented text."""
    attrs = G.nodes[node_id]
    in_deg = G.in_degree(node_id)
    out_deg = G.out_degree(node_id)
    tier = attrs.get("tier", 1)
    criticality = attrs.get("criticality_score", 0.0)
    risk = risk_scores.get(node_id, 0.0)

    reasons = []
    if in_deg >= 3:
        reasons.append(f"High dependency: {in_deg} downstream companies rely on it")
    if tier >= 2:
        reasons.append(f"Deep-tier node (Tier {tier}) — low visibility, harder to reroute around")
    if criticality >= 0.7:
        reasons.append(f"High criticality score ({criticality:.2f}) from anchor-layer data")
    if not reasons:
        reasons.append("Moderate/low structural risk — limited downstream dependency")

    return {
        "node_id": node_id, "name": attrs.get("name"), "risk_score": round(risk, 4),
        "in_degree": in_deg, "out_degree": out_deg, "tier": tier,
        "criticality_score": criticality, "reasons": reasons,
    }


def compute_scenario_impact(G: nx.DiGraph, scenario: dict, risk_scores: dict) -> dict:
    direct_ids = find_direct_impact(G, scenario["region"], scenario["affected_industries"])
    indirect_hops = find_indirect_impact(G, direct_ids)

    all_industries = set(G.nodes[n]["industry"] for n in direct_ids + list(indirect_hops.keys()))
    all_regions = set(G.nodes[n]["country"] for n in direct_ids + list(indirect_hops.keys()))

    return {
        "scenario_id": scenario["id"],
        "direct_impact": [explain_risk(G, n, risk_scores) for n in direct_ids],
        "indirect_impact": [
            {**explain_risk(G, n, risk_scores), "hop": hop}
            for n, hop in sorted(indirect_hops.items(), key=lambda x: x[1])
        ],
        "direct_count": len(direct_ids),
        "indirect_count": len(indirect_hops),
        "industries_affected": sorted(all_industries),
        "regions_affected": sorted(all_regions),
        "max_hop": max(indirect_hops.values()) if indirect_hops else 0,
    }


if __name__ == "__main__":
    with open(DATA_DIR / "shock_scenarios.json") as f:
        scenarios = json.load(f)
    with open(DATA_DIR / "trade_graph_ntier.json") as f:
        G = nx.node_link_graph(json.load(f), directed=True)

    risk_path = DATA_DIR / "risk_scores.json"
    risk_scores = json.load(open(risk_path)) if risk_path.exists() else {}

    for scenario in scenarios:
        impact = compute_scenario_impact(G, scenario, risk_scores)
        print(f"\n{scenario['id']}: {scenario['type']} — {scenario['region']}")
        print(f"  Direct impact:   {impact['direct_count']} companies")
        print(f"  Indirect impact: {impact['indirect_count']} companies "
              f"(up to {impact['max_hop']} hops away)")
        print(f"  Industries affected: {', '.join(impact['industries_affected'])}")
        print(f"  Regions affected:    {', '.join(impact['regions_affected'])}")
