"""
Day 4 - RAG Mitigation Agent (upgraded)

- Local FAISS vector store (no Pinecone/Milvus)
- sentence-transformers embeddings
- Retrieval-based mitigation suggestions
- Supports both text plan + structured plan for UI
"""

import json
from pathlib import Path
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


# =========================================================
# 🔹 FAISS STORE (Local Vector DB)
# =========================================================
class FaissStore:
    def __init__(self):
        self.model = SentenceTransformer("all-MiniLM-L6-v2")

        self.documents = [
            "Shift sourcing to alternate regions with similar capabilities",
            "Diversify suppliers to reduce single point of failure",
            "Increase inventory buffer for critical components",
            "Nearshore manufacturing to reduce geopolitical risk",
            "Use substitute materials where possible",
            "Prioritize high-centrality suppliers for recovery",
            "Reroute logistics through unaffected ports",
            "Collaborate with regional partners for contingency supply",
            "Switch to secondary semiconductor suppliers in Korea or Japan",
            "Move textile sourcing to Bangladesh or Vietnam",
        ]

        self.embeddings = self.model.encode(self.documents)
        self.index = faiss.IndexFlatL2(self.embeddings.shape[1])
        self.index.add(np.array(self.embeddings).astype("float32"))

    def query(self, text, k=3):
        query_vec = self.model.encode([text])
        D, I = self.index.search(np.array(query_vec).astype("float32"), k)

        results = []
        for idx in I[0]:
            results.append(self.documents[idx])
        return results


# =========================================================
# 🔹 TEXT MITIGATION PLAN (Human-readable)
# =========================================================
def generate_mitigation_plan(scenario, affected_nodes, retrieved_context):
    """
    Generates readable paragraph-style mitigation plan
    """

    severity = scenario["severity"]
    duration = scenario["duration_days"]

    if severity >= 0.7:
        severity_label = "HIGH"
    elif severity >= 0.4:
        severity_label = "MEDIUM"
    else:
        severity_label = "LOW"

    node_names = [n["name"] for n in affected_nodes[:3]]

    plan = f"""
MITIGATION PLAN — {scenario['type']} ({scenario['region']})
-----------------------------------------------------------
Severity: {severity_label} ({severity})
Estimated Duration: {duration} days

At-risk nodes: {", ".join(node_names) if node_names else "None"}

Recommended Actions:
"""

    for i, action in enumerate(retrieved_context, 1):
        plan += f"{i}. {action}\n"

    plan += "\nRecommendation: prioritize high-centrality nodes first."

    return plan.strip()


# =========================================================
# 🔹 STRUCTURED PLAN (for frontend UI)
# =========================================================
def generate_structured_plan(scenario: dict, retrieved_context: list) -> dict:
    """
    Machine-friendly version of the plan for UI rendering
    """

    severity = scenario["severity"]

    if severity >= 0.7:
        severity_label = "High"
    elif severity >= 0.4:
        severity_label = "Medium"
    else:
        severity_label = "Low"

    return {
        "severity": severity,
        "severity_label": severity_label,
        "duration_days": scenario["duration_days"],
        "top_actions": retrieved_context,
        "priority_industry": scenario["affected_industries"][0]
        if scenario.get("affected_industries") else None,
    }


# =========================================================
# 🔹 RUN SINGLE SCENARIO (optional utility)
# =========================================================
def run_scenario(scenario: dict, affected_nodes: list):
    """
    Full pipeline for one scenario:
    - retrieve context
    - generate plan
    - return both formats
    """

    store = FaissStore()

    query = f"{scenario['type']} {scenario['region']} mitigation"
    retrieved_context = store.query(query)

    plan_text = generate_mitigation_plan(
        scenario, affected_nodes, retrieved_context
    )

    structured_plan = generate_structured_plan(
        scenario, retrieved_context
    )

    return {
        "plan_text": plan_text,
        "plan": structured_plan
    }


# =========================================================
# 🔹 DEBUG RUN (optional)
# =========================================================
if __name__ == "__main__":
    # Example test scenario
    test_scenario = {
        "id": "test_1",
        "type": "Environmental Disaster",
        "region": "India",
        "severity": 0.7,
        "duration_days": 30,
        "affected_industries": ["Agri"]
    }

    affected = [
        {"id": "N001", "name": "Brightloom Group"},
        {"id": "N002", "name": "Atlas Foundry"}
    ]

    result = run_scenario(test_scenario, affected)

    print("\n--- TEXT PLAN ---\n")
    print(result["plan_text"])

    print("\n--- STRUCTURED PLAN ---\n")
    print(json.dumps(result["plan"], indent=2))
