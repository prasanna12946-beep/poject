import json
from pathlib import Path

import networkx as nx

from rag_agent import FaissStore, generate_structured_plan, generate_mitigation_plan
from impact_analysis import compute_scenario_impact

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def run_all_scenarios():
    with open(DATA_DIR / "shock_scenarios.json") as f:
        scenarios = json.load(f)
    with open(DATA_DIR / "trade_graph_ntier.json") as f:
        G = nx.node_link_graph(json.load(f), directed=True)

    risk_path = DATA_DIR / "risk_scores.json"
    risk_scores = json.load(open(risk_path)) if risk_path.exists() else {}

    store = FaissStore()
    results = {}

    for scenario in scenarios:
        impact = compute_scenario_impact(G, scenario, risk_scores)
        direct_ids = [n["node_id"] for n in impact["direct_impact"]]
        indirect_ids = [n["node_id"] for n in impact["indirect_impact"]]
        all_affected = [{"id": n["node_id"], "name": n["name"]}
                         for n in impact["direct_impact"]]

        context = store.query(f"{scenario['type']} {scenario['region']} mitigation")
        plan_text = generate_mitigation_plan(scenario, all_affected, context)
        structured_plan = generate_structured_plan(scenario, context)

        print("=" * 70)
        print(f"{scenario['id']}: {scenario['type']} — {scenario['region']}")
        print(f"Direct: {impact['direct_count']}  Indirect: {impact['indirect_count']} "
              f"(up to {impact['max_hop']} hops)")
        if impact['direct_count'] == 0:
            print("  WARNING: zero direct-impact nodes — check region/industry spelling")
        print(plan_text)
        print()

        results[scenario["id"]] = {
            "scenario_id": scenario["id"],
            "type": scenario["type"],
            "region": scenario["region"],
            "direct_count": impact["direct_count"],
            "indirect_count": impact["indirect_count"],
            "max_hop": impact["max_hop"],
            "industries_affected": impact["industries_affected"],
            "regions_affected": impact["regions_affected"],
            "direct_node_ids": direct_ids,
            "indirect_node_hops": {n["node_id"]: n["hop"] for n in impact["indirect_impact"]},
            "plan_text": plan_text,
            "plan": structured_plan,
        }

    with open(DATA_DIR / "shock_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print(f"Saved full results to {DATA_DIR / 'shock_results.json'}")

    zero_hit = [sid for sid, r in results.items() if r["direct_count"] == 0]
    if zero_hit:
        print(f"\nWARNING - scenarios with NO direct impact (fix before demo): {zero_hit}")
    else:
        print("\nAll scenarios found direct + indirect impact")


if __name__ == "__main__":
    run_all_scenarios()
