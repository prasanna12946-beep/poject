import json
from pathlib import Path
import networkx as nx

from impact_analysis import explain_risk

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


if __name__ == "__main__":
    with open(DATA_DIR / "trade_graph_ntier.json") as f:
        G = nx.node_link_graph(json.load(f), directed=True)

    risk_path = DATA_DIR / "risk_scores.json"
    risk_scores = json.load(open(risk_path)) if risk_path.exists() else {}

    explanations = {n: explain_risk(G, n, risk_scores) for n in G.nodes}

    with open(DATA_DIR / "node_explanations.json", "w") as f:
        json.dump(explanations, f, indent=2)

    print(f"Wrote explanations for {len(explanations)} nodes to "
          f"{DATA_DIR / 'node_explanations.json'}")

